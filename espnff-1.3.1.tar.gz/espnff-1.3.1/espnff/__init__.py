from .espnff import League, Team

__all__ = ['League', 'Team']
